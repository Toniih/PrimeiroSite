import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const Inquilino = () => {
    const [inquilino, setInquilino] = useState([])

    useEffect(() => {
        axios.get("http://localhost:8800/")
        .then(res => setInquilino(res.data))
        .catch(err => console.log(err))
    }, [])

    return (
        <div className="outbox">
            <div className="inbox">
                <Link to="/Adicionar" className="botaoAdd">Add +</Link>
                <table className="tabela">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Telefone</th>
                            <th>Numero do casa</th>
                            <td>
                                <button className="upt">Atualizar</button>
                                <button className="del">Deletar</button>
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        {
                        inquilino.map((data, i) => (
                            <tr key={i}>
                                <td>{data.nome}</td>
                                <td>{data.fone}</td>
                                <td>{data.numero}</td>
                            </tr>
                        ))
                        }
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default Inquilino;
