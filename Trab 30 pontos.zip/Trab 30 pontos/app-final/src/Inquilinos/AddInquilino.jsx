import axios from "axios";
import React, { useState } from "react";

const AddInquilino = () => {
    const [nome, setNome] = useState("")
    const [fone, setFone] = useState("")
    const [numero, setNumero] = useState("")

function handleSubmit(event) {
    event.preventDefault();
    axios.post('http://localhost:8800/Adicionar', (nome, fone, numero))
    .them(res => {
        console.log(res); /*Parei aqui(muitos problemas com mySql*/
    })
}

    return (
        <div>
            <div>
                <form onSubmit={handleSubmit}>
                    <h2>Adicionar inquilino</h2>
                    <div className="entradas">
                        <label htmlFor="">Nome</label>
                        <input type="text" placeholder="Insirir nome" className="input-form" />
                        onChange={e => setNome(e.target.value)}
                    </div>
                    <div className="entradas">
                        <label htmlFor="">Telefone</label>
                        <input type="tel" placeholder="Insirir numero de celular" className="input-form" />
                        onChange={e => setFone(e.target.value)}
                    </div>
                    <div className="entradas">
                        <label htmlFor="">Numero</label>
                        <input type="number" placeholder="Insirir da casa" className="input-form" />
                        onChange={e => setNumero(e.target.value)}
                    </div>
                    <button className="botaoAdd">Enviar</button>
                </form>
            </div>
        </div>
    )
}

export default AddInquilino;