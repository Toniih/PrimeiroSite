import './App.css';
import {BrowserRouter, Routes, Route} from "react-router-dom";
import Inquilino from './Inquilinos/Inquilino';
import AddInquilino from './Inquilinos/AddInquilino';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Inquilino/>}></Route>
          <Route path='/Adicionar' element={<AddInquilino />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
